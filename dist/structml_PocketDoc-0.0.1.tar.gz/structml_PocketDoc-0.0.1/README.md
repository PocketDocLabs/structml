# structml
A package for working with data using NLP and ML.

## Installation
```bash
pip install structml
```